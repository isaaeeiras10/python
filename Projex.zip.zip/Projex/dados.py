contas = [
    {"id": 1, "nome": "Isabela", "total": 10.0}
    ,{"id": 2, "nome": "Heitor", "total": 15.0}
    ,{"id": 3, "nome": "Manuela", "total": 20.0}
    ,{"id": 4, "nome": "Leandro", "total": 12.5}
    ,{"id": 5, "nome": "Pedro", "total": 8.0}
    ,{"id": 6, "nome": "Giovanna", "total": 17.5}
    ,{"id": 7, "nome": "Marcos", "total": 23.0}
    ,{"id": 8, "nome": "Gustavo", "total": 11.5}
    ,{"id": 9, "nome": "Lissa", "total": 16.0}
    ,{"id": 10, "nome": "Arthur", "total": 19.0}
]


despesas = [
    {"id": 1091, "pago": True, "data": "08/03", "descricao": "Aluguel", "conta_id": 1}
    ,{"id": 1092, "pago": True,  "data": "09/03", "descricao": "Supermercado", "conta_id": 2}
    ,{"id": 1093, "pago": True, "data": "10/03", "descricao": "Gasolina", "conta_id": 3}
    ,{"id": 1094, "pago": True, "data": "11/03", "descricao": "Restaurante", "conta_id": 4}
    ,{"id": 1095, "pago": True, "data": "12/03", "descricao": "Eletrônicos", "conta_id": 5}
    ,{"id": 1096, "pago": False, "data": "13/03", "descricao": "Transporte", "conta_id": 6}
    ,{"id": 1097, "pago": True, "data": "14/03", "descricao": "Roupas", "conta_id": 7}
    ,{"id": 1098, "pago": True, "data": "15/03", "descricao": "Assinaturas", "conta_id": 8}
    ,{"id": 1099, "pago": True, "data": "16/03", "descricao": "Lazer", "conta_id": 9}
    ,{"id": 1100, "pago": True, "data": "17/03", "descricao": "Saúde", "conta_id": 10}
]